import React, { useState, useEffect } from 'react';
import { Calculator, TrendingUp, DollarSign, Clock, Users, Settings, Download, Mail, Factory, Package } from 'lucide-react';
import SliderInput from './SliderInput';
import { jsPDF } from 'jspdf';
import logo from '../Images/64469a0e797d2d34b5888432_Machine-Solutions-p-500.jpg';

const ROICalculator = () => {
  const [inputs, setInputs] = useState({
    // Labor - Current
    workShiftsCurrent: 1,
    daysPerYearCurrent: 250,
    hoursPerShiftCurrent: 8,
    weeksPerYearCurrent: 52,
    operatorsPerShiftCurrent: 6,
    operatorHoursCurrent: 40,
    operatorWageCurrent: 25,
    annualCostPerOperatorCurrent: 52000,
    techniciansCurrent: 0,
    annualCostPerTechnicianCurrent: 75000,
    
    // Labor - Post Install
    workShiftsPost: 1,
    daysPerYearPost: 250,
    hoursPerShiftPost: 8,
    weeksPerYearPost: 52,
    operatorsPerShiftPost: 1,
    operatorHoursPost: 40,
    operatorWagePost: 25,
    annualCostPerOperatorPost: 52624,
    techniciansPost: 1,
    annualCostPerTechnicianPost: 75000,
    
    // Materials
    annualPartsGoalCurrent: 1000000,
    annualPartsGoalPost: 1000000,
    machineUptimeCurrent: 83,
    machineUptimePost: 90,
    scrapPercentageCurrent: 5,
    scrapPercentagePost: 1,
    materialCostPerUnitCurrent: 11.50,
    materialCostPerUnitPost: 11.50,   
    
    // Revenue
    sellPricePerPartCurrent: 19.00,
    sellPricePerPartPost: 19.00,
    
    // Capital Equipment
    newEquipmentCost: 2000000
  });

  const [results, setResults] = useState({});
  const [showResults, setShowResults] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [formData, setFormData] = useState(() => {
    return {
      company: '',
      salesperson: '',
      email: '',
      phone: '',
      productName: '',
      productModel: ''
    };
  });
  const [step, setStep] = useState('ask'); // 'ask' | 'form'

  // Calculate all metrics
  useEffect(() => {
    // Current State Calculations
    const totalOperatorsCurrent = inputs.workShiftsCurrent * inputs.operatorsPerShiftCurrent;
    const annualCostPerOperatorCurrent = inputs.operatorHoursCurrent * inputs.operatorWageCurrent * inputs.weeksPerYearCurrent * 1.15;
    const totalOperatorsCostCurrent = totalOperatorsCurrent * annualCostPerOperatorCurrent;   
    const totalTechniciansCostCurrent = inputs.techniciansCurrent * inputs.annualCostPerTechnicianCurrent; 
    const totalLaborCostCurrent = totalOperatorsCostCurrent + totalTechniciansCostCurrent;
    
    // Post Install Calculations
    const totalOperatorsPost = inputs.workShiftsPost * inputs.operatorsPerShiftPost;
    const annualCostPerOperatorPost = inputs.operatorHoursPost * inputs.operatorWagePost * inputs.weeksPerYearPost * 1.15;
    const totalOperatorsCostPost = totalOperatorsPost * annualCostPerOperatorPost;
    const totalTechniciansCostPost = inputs.techniciansPost * inputs.annualCostPerTechnicianPost;
    const totalLaborCostPost = totalOperatorsCostPost + totalTechniciansCostPost;
    
    // Material Calculations - Current
    const totalPartsProducedGrossCurrent = Math.round(inputs.annualPartsGoalCurrent * (inputs.machineUptimeCurrent / 100));
    const totalPartsProducedNetCurrent = totalPartsProducedGrossCurrent * (1 - inputs.scrapPercentageCurrent / 100);
    const annualMaterialCostCurrent = totalPartsProducedGrossCurrent * inputs.materialCostPerUnitCurrent;
    
    // Material Calculations - Post Install
    const totalPartsProducedGrossPost = Math.round(inputs.annualPartsGoalPost * (inputs.machineUptimePost / 100));
    const totalPartsProducedNetPost = totalPartsProducedGrossPost * (1 - inputs.scrapPercentagePost / 100);
    const annualMaterialCostPost = totalPartsProducedGrossPost * inputs.materialCostPerUnitPost;
    
    // Revenue Calculations
    const annualRevenueCurrent = totalPartsProducedNetCurrent * inputs.sellPricePerPartCurrent;
    const contributionMarginCurrent = annualRevenueCurrent - (totalLaborCostCurrent + annualMaterialCostCurrent);
    const contributionMarginRatioCurrent = (contributionMarginCurrent / annualRevenueCurrent) * 100;
    
    const annualRevenuePost = totalPartsProducedNetPost * inputs.sellPricePerPartPost;
    const contributionMarginPost = annualRevenuePost - (totalLaborCostPost + annualMaterialCostPost);
    const contributionMarginRatioPost = (contributionMarginPost / annualRevenuePost) * 100;
    
    // Improvement Calculations
    const contributionMarginImprovement = contributionMarginPost - contributionMarginCurrent;
    const laborSavings = totalLaborCostCurrent - totalLaborCostPost;
    const materialSavings = annualMaterialCostCurrent - annualMaterialCostPost;
    const revenueSavings = annualRevenuePost - annualRevenueCurrent;
    
    // ROI Calculations
    const year1CashFlow = contributionMarginImprovement - inputs.newEquipmentCost;
    const year2CashFlow = (2*contributionMarginImprovement) - inputs.newEquipmentCost;
    const year3CashFlow = (3*contributionMarginImprovement) - inputs.newEquipmentCost;
    
    // const netCashFlow = year1CashFlow + year2CashFlow + year3CashFlow;
    const netCashFlow = (totalLaborCostCurrent - totalLaborCostPost) + (inputs.annualCostPerTechnicianCurrent - inputs.annualCostPerTechnicianPost) + contributionMarginImprovement;
    
    // NPV Calculation (10% discount rate)
    const discountRate = 0.10;
    const npv = year1CashFlow + 
                (year2CashFlow / Math.pow(1 + discountRate, 2)) + 
                (year3CashFlow / Math.pow(1 + discountRate, 3));
    
    // IRR Calculation (simplified)
    const totalCashFlows = contributionMarginImprovement * 3;
    const irr = totalCashFlows > inputs.newEquipmentCost ? 
                Math.pow(totalCashFlows / inputs.newEquipmentCost, 1/3) - 1 : 0;
    
    // Payback Period
    const paybackPeriod = contributionMarginImprovement > 0 ? 
                         (inputs.newEquipmentCost / contributionMarginImprovement) * 12 : 'N/A';

    const newResults = {
      // Current State
      totalOperatorsCurrent,
      annualCostPerOperatorCurrent,
      totalOperatorsCostCurrent,
      totalTechniciansCostCurrent,
      totalLaborCostCurrent,
      totalPartsProducedGrossCurrent,
      totalPartsProducedNetCurrent,
      annualMaterialCostCurrent,
      annualRevenueCurrent,
      contributionMarginCurrent,
      contributionMarginRatioCurrent,
      
      // Post Install
      totalOperatorsPost,
      annualCostPerOperatorPost,
      totalOperatorsCostPost,
      totalTechniciansCostPost,
      totalLaborCostPost,
      totalPartsProducedGrossPost,
      totalPartsProducedNetPost,
      annualMaterialCostPost,
      annualRevenuePost,
      contributionMarginPost,
      contributionMarginRatioPost,
      
      // Improvements
      contributionMarginImprovement,
      laborSavings,
      materialSavings,
      revenueSavings,
      
      // ROI Metrics
      year1CashFlow,
      year2CashFlow,
      year3CashFlow,
      netCashFlow,
      npv,
      irr: irr * 100,
      paybackPeriod
    };

    console.log('Calculated Results:', newResults);
    setResults(newResults);
    
    // Debugging: Log results after setting state
    console.log('Results calculated and set:', newResults);

  }, [inputs]);

  const handleInputChange = (field, value) => {
    setInputs(prev => ({ ...prev, [field]: parseFloat(value) || 0 }));
  };

  const handleDownloadPDF = (info = {}) => {
    console.log('Inside handleDownloadPDF. Results state:', results);

    const doc = new jsPDF();
    const {
      company = '',
      salesperson = '',
      email = '',
      phone = '',
      productName = '',
      productModel = ''
    } = info;
    
    const margin = 7;
    let yPosition = margin;
    const pageWidth = doc.internal.pageSize.width;
    
    // Add logo and title side by side
    doc.addImage(logo, 'JPEG', margin, yPosition, 35, 26);
    
    // Add title next to logo
    doc.setFontSize(20);
    doc.setFont(undefined, 'bold');
    doc.text('ROI Calculator', margin + 40, yPosition + 15); // Position text next to logo
    yPosition += 30; // Add space after logo and title

    doc.setFontSize(10);
    doc.setFont(undefined, 'normal');
    doc.text('Machine Solutions | Medical Device Manufacturing', margin + 40, yPosition - 10);  

    if (company || salesperson || email || phone || productName || productModel) {
      doc.setFontSize(11);
      doc.setFont(undefined, 'bold');
      doc.text(`Prepared for: ${company}`, margin, yPosition);
      yPosition += 7;
      doc.text(`Prepared by: ${salesperson} ${email} ${phone}`, margin, yPosition);
      yPosition += 7;
      doc.text(`Product: ${productName}`, margin, yPosition);
      yPosition += 7;
      doc.text(`Model#: ${productModel}`, margin, yPosition);
      yPosition += 15;
    }

    // Helper function to add footer with date
    const addFooter = (pageNumber) => {
      const pageHeight = doc.internal.pageSize.height;
      doc.setFontSize(10);
      doc.setFont(undefined, 'normal');
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, margin, pageHeight - 10);
      doc.text(`Page ${pageNumber}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
    };

    // Helper function to draw a section with proper table format
    const drawSection = (title, leftColumnData, rightColumnData, yPos) => {
      // Check if we need a new page
      if (yPos > doc.internal.pageSize.height - 50) {
        addFooter(doc.internal.getNumberOfPages());
        doc.addPage();
        yPos = margin;
      }

      // Section header with background
      doc.setFillColor(111, 190, 76);
      doc.rect(0, yPos, pageWidth, 15, 'F');
      doc.setFontSize(14);
      doc.setFont(undefined, 'bold');
      doc.setTextColor(255,255,255);
      doc.text(title, pageWidth / 2, yPos + 10, { align: 'center' });
      yPos += 25;
      doc.setTextColor(0, 0, 0);

      // Column headers
      const leftColStart = pageWidth * 0.05;
      const rightColStart = pageWidth * 0.55;
      const colWidth = pageWidth * 0.4;


      doc.setFontSize(12);
      doc.setFont(undefined, 'bold');
      doc.text('Current', leftColStart + colWidth/2, yPos, { align: 'center' });
      doc.text('Post Install', rightColStart + colWidth/2, yPos, { align: 'center' });
      yPos += 15;

      // Draw the data in two columns
      const maxRows = Math.max(leftColumnData.length, rightColumnData.length);
      
      for (let i = 0; i < maxRows; i++) {
        doc.setFontSize(10);
        
        // Left column data
        if (leftColumnData[i]) {
          doc.setFont(undefined, 'normal');
          doc.text(leftColumnData[i][0], leftColStart, yPos);
          doc.setFont(undefined, 'bold');
          doc.text(leftColumnData[i][1].toString(), leftColStart + colWidth - 10, yPos, { align: 'right' });
        }
        
        // Right column data
        if (rightColumnData[i]) {
          doc.setFont(undefined, 'normal');
          doc.text(rightColumnData[i][0], rightColStart, yPos);
          doc.setFont(undefined, 'bold');
          doc.text(rightColumnData[i][1].toString(), rightColStart + colWidth - 10, yPos, { align: 'right' });
        }
        
        yPos += 6;
      }

      return yPos + 10;
    };

    // Labor Configuration Section
    const laborCurrentData = [
      ['Work Shifts', inputs.workShiftsCurrent || 0],
      ['Days per Year', inputs.daysPerYearCurrent || 0],
      ['Hours per Shift', inputs.hoursPerShiftCurrent || 0],
      ['Operators per Shift', inputs.operatorsPerShiftCurrent || 0],
      ['Operator Hours/Week', inputs.operatorHoursCurrent || 0],
      ['Operator Wage ($/hr)', `$${(inputs.operatorWageCurrent || 0).toLocaleString()}`],
      ['Technicians', inputs.techniciansCurrent || 0],
      ['Annual Cost per Operator', `$${(results.annualCostPerOperatorCurrent || 0).toLocaleString()}`],
      ['Annual Cost per Technician', `$${(inputs.annualCostPerTechnicianCurrent || 0).toLocaleString()}`]
    ];

    const laborPostData = [
      ['Work Shifts', inputs.workShiftsPost || 0],
      ['Days per Year', inputs.daysPerYearPost || 0],
      ['Hours per Shift', inputs.hoursPerShiftPost || 0],
      ['Operators per Shift', inputs.operatorsPerShiftPost || 0],
      ['Operator Hours/Week', inputs.operatorHoursPost || 0],
      ['Operator Wage ($/hr)', `$${(inputs.operatorWagePost || 0).toLocaleString()}`],
      ['Technicians', inputs.techniciansPost || 0],
      ['Annual Cost per Operator', `$${(results.annualCostPerOperatorPost || 0).toLocaleString()}`],
      ['Annual Cost per Technician', `$${(inputs.annualCostPerTechnicianPost || 0).toLocaleString()}`]
    ];

    yPosition = drawSection('Labor Configuration', laborCurrentData, laborPostData, yPosition);

    // Materials & Production Section
    const materialsCurrentData = [
      ['Annual Parts Goal', (inputs.annualPartsGoalCurrent || 0).toLocaleString()],
      ['Machine Uptime', `${inputs.machineUptimeCurrent || 0}%`],
      ['Scrap Percentage', `${inputs.scrapPercentageCurrent || 0}%`],
      ['Material Cost per Unit', `$${(inputs.materialCostPerUnitCurrent || 0).toLocaleString()}`],
      ['Sell Price per Part', `$${(inputs.sellPricePerPartCurrent || 0).toLocaleString()}`]
    ];

    const materialsPostData = [
      ['Annual Parts Goal', (inputs.annualPartsGoalPost || 0).toLocaleString()],
      ['Machine Uptime', `${inputs.machineUptimePost || 0}%`],
      ['Scrap Percentage', `${inputs.scrapPercentagePost || 0}%`],
      ['Material Cost per Unit', `$${(inputs.materialCostPerUnitPost || 0).toLocaleString()}`],
      ['Sell Price per Part', `$${(inputs.sellPricePerPartPost || 0).toLocaleString()}`]
    ];

    yPosition = drawSection('Materials & Production', materialsCurrentData, materialsPostData, yPosition);

    // Investment & Revenue Section
    const investmentCurrentData = [
      ['New Equipment Cost', `$${(inputs.newEquipmentCost || 0).toLocaleString()}`],
      ['Sell Price per Part', `$${(inputs.sellPricePerPartCurrent || 0).toLocaleString()}`]
    ];

    const investmentPostData = [
      ['New Equipment Cost', `$${(inputs.newEquipmentCost || 0).toLocaleString()}`],
      ['Sell Price per Part', `$${(inputs.sellPricePerPartPost || 0).toLocaleString()}`]
    ];

    // Force new page before Investment & Revenue section
    doc.addPage();
    yPosition = margin;

    yPosition = drawSection('Investment & Revenue', investmentCurrentData, investmentPostData, yPosition);


    // Check if we need a new page
    if (yPosition > 200) {
      doc.addPage();
      yPosition = margin;
    }

    // Results Section Header
    doc.setFillColor(111, 190, 76);
    doc.rect(0, yPosition, pageWidth, 15, 'F');
    doc.setFontSize(14);
    doc.setTextColor(255,255,255);
    doc.setFont(undefined, 'bold');
    doc.text('ROI Analysis Results', pageWidth / 2, yPosition + 10, { align: 'center' });
    yPosition += 25;
    doc.setTextColor(0,0,0);

    // Two-column results layout
    const sectionMargin = pageWidth * 0.05; // match other sections (left 5%)
    const leftTableX = sectionMargin;
    const leftTableWidth = pageWidth * 0.55; // narrower to give space for right column
    const rightTableX = sectionMargin + leftTableWidth + 10; // right beside it



    // Left side: Current vs Post Install
    doc.setFontSize(12);
    doc.setFont(undefined, 'bold');
    doc.text('Current vs Post Install', leftTableX, yPosition);
    
    // Right side: 3-Year ROI
    doc.text('3-Year ROI', rightTableX, yPosition);
    yPosition += 15;

    // Current vs Post Install table data
    const comparisonData = [
      ['Total Labor Cost', 
       `$${(results.totalLaborCostCurrent || 0).toLocaleString()}`, 
       `$${(results.totalLaborCostPost || 0).toLocaleString()}`],
      ['Material Cost', 
       `$${(results.annualMaterialCostCurrent || 0).toLocaleString()}`, 
       `$${(results.annualMaterialCostPost || 0).toLocaleString()}`],
      ['Annual Revenue', 
       `$${(results.annualRevenueCurrent || 0).toLocaleString()}`, 
       `$${(results.annualRevenuePost || 0).toLocaleString()}`],
      ['Contribution Margin', 
       `$${(results.contributionMarginCurrent || 0).toLocaleString()}`, 
       `$${(results.contributionMarginPost || 0).toLocaleString()}`]
    ];

    // ROI table data
    const roiData = [
      ['Year 1', `$${(results.year1CashFlow || 0).toLocaleString()}`],
      ['Year 2', `$${(results.year2CashFlow || 0).toLocaleString()}`],
      ['Year 3', `$${(results.year3CashFlow || 0).toLocaleString()}`],
      ['Net Cash Flow', `$${(results.netCashFlow || 0).toLocaleString()}`]
    ];

    let leftTableY = yPosition;
    let rightTableY = yPosition;

    // Draw left table headers
    doc.setFontSize(10);
    doc.setFont(undefined, 'bold');
    doc.text('Metric', leftTableX, leftTableY);
    doc.text('Current', leftTableX + leftTableWidth * 0.42, leftTableY, { align: 'center' });
    doc.text('Post Install', leftTableX + leftTableWidth * 0.68, leftTableY, { align: 'center' });


    leftTableY += 12;

    // Draw right table headers
    doc.text('Year', rightTableX, rightTableY);
    doc.text('ROI ', rightTableX + 60, rightTableY, { align: 'right' });
    rightTableY += 12;

    // Draw left table (Current vs Post Install)
    comparisonData.forEach((row) => {
      doc.setFontSize(10);
      doc.setFont(undefined, 'normal');
      doc.text(row[0], leftTableX, leftTableY);
      doc.setFont(undefined, 'bold');
      doc.text(row[1], leftTableX + leftTableWidth * 0.42, leftTableY, { align: 'center' });
      doc.text(row[2], leftTableX + leftTableWidth * 0.68, leftTableY, { align: 'center' });


      leftTableY += 7;
    });

    // Draw right table (3-Year ROI)
    roiData.forEach((row) => {
      doc.setFontSize(10);
      doc.setFont(undefined, 'normal');
      doc.text(row[0], rightTableX, rightTableY);
      doc.setFont(undefined, 'bold');
      doc.text(row[1], rightTableX + 60, rightTableY, { align: 'right' });
      rightTableY += 7;
    });

    // Key Metrics Summary
    yPosition = Math.max(leftTableY, rightTableY) + 20;
    
    // Check if we need a new page for key metrics
    if (yPosition > 220) {
      doc.addPage();
      yPosition = margin;
    }
    
    doc.setFontSize(12);
    doc.setFont(undefined, 'bold');
    doc.text('Key Performance Indicators', margin, yPosition);
    yPosition += 15;

    const keyMetrics = [
      ['Contribution Margin Improvement', `$${(results.contributionMarginImprovement || 0).toLocaleString()}`],
      ['Payback Period', typeof results.paybackPeriod === 'number' ? `${results.paybackPeriod.toFixed(1)} months` : 'N/A'],
      ['Internal Rate of Return', `${(results.irr || 0).toFixed(1)}%`],
      ['Net Present Value', `$${(results.npv || 0).toLocaleString()}`]
    ];

    keyMetrics.forEach(([label, value]) => {
      doc.setFontSize(10);
      doc.setFont(undefined, 'normal');
      doc.text(label + ':', margin, yPosition);
      doc.setFont(undefined, 'bold');
      doc.text(value, margin + 100, yPosition, { align: 'right' });
      yPosition += 7;
    });

    // After all content is added, add footer to the last page
    addFooter(doc.internal.getNumberOfPages());

    // Save the PDF
    doc.save('roi-calculator-report.pdf');
  };
  
  
  

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">

  {showPopup && (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex justify-center items-center">
      <div className="bg-white p-6 rounded-xl shadow-xl w-[90%] max-w-md">

        {step === 'ask' && (
          <>
            <h2 className="text-xl font-bold mb-4 text-center text-darkBlue">Add details to the PDF?</h2>
            <div className="flex justify-end space-x-3">
              <button onClick={() => {
                setShowPopup(false);
                setShowResults(true); // Trigger fresh calculations
                setTimeout(() => handleDownloadPDF(), 100); // Wait for calculations to complete
              }} className="px-4 py-2 text-gray-600">No</button>

              <button onClick={() => setStep('form')} className="px-4 py-2 bg-darkBlue text-white rounded-md">Yes</button>
            </div>
          </>
        )}

        {step === 'form' && (
          <>
            <h2 className="text-xl font-bold mb-4 text-center">Enter Report Details</h2>
            {['company', 'salesperson', 'email', 'phone', 'productName', 'productModel'].map((key) => (
              <input
                key={key}
                type="text"
                placeholder={key.replace(/([A-Z])/g, ' $1').replace(/^\w/, c => c.toUpperCase())}
                value={formData[key]}
                onChange={(e) => setFormData({ ...formData, [key]: e.target.value })}
                className="w-full mb-3 px-4 py-2 border rounded-md"
              />
            ))}
            <div className="flex justify-end space-x-3">
              <button onClick={() => setShowPopup(false)} className="px-4 py-2 text-gray-600">Cancel</button>
              <button
                className="px-4 py-2 bg-darkBlue text-white rounded-md"
                onClick={() => {
                  localStorage.setItem('roiUserInfo', JSON.stringify(formData));
                  setShowPopup(false);
                  setShowResults(true); // Ensure calculation
                  setTimeout(() => {
                    handleDownloadPDF(formData); // with details
                    setStep('ask'); // reset for next time
                  }, 100);
                }}
              >
                Submit & Download
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )}



      {/* Header */}
      <div className="bg-white shadow-lg border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="logo rounded-lg flex items-center justify-center">
                <img src={logo} alt="Logo" className="w-full h-full object-contain" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-darkBlue">ROI Calculator</h1>
                <p className="text-sm text-darkBlue">Machine Solutions | Medical Device Manufacturing</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <button 
                onClick={() => setShowPopup(true)}
                className="p-2 text-lightGreen hover :bg-blue-50 rounded-lg transition-colors"
                title="Download Report"
              >
                <Download className="w-5 h-5" />
              </button>
              {/* <button className="p-2 text-black-333 hover:bg-blue-50 rounded-lg transition-colors">
                <Mail className="w-5 h-5" />
              </button> */}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="calculator-container grid gap-8">
          {/* Input Panel */}
          <div className="space-y-8">
            {/* Labor Section */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex items-center space-x-3 mb-8">
                <Users className="w-6 h-6 text-lightGreen" />
                <h2 className="text-xl font-bold text-darkBlue">Labor Configuration</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div>
                  <h3 className="text-lg font-semibold text-darkBlue mb-4">Current State</h3>
                  <SliderInput
                    label="Work Shifts"
                    value={inputs.workShiftsCurrent}
                    onChange={(value) => handleInputChange('workShiftsCurrent', value)}
                    min={1}
                    max={3}
                  />
                  <SliderInput
                    label="Days per Year"
                    value={inputs.daysPerYearCurrent}
                    onChange={(value) => handleInputChange('daysPerYearCurrent', value)}
                    min={200}
                    max={365}
                  />
                  <SliderInput
                    label="Hours per Shift"
                    value={inputs.hoursPerShiftCurrent}
                    onChange={(value) => handleInputChange('hoursPerShiftCurrent', value)}
                    min={6}
                    max={12}
                  />
                  <SliderInput
                    label="Operators per Shift"
                    value={inputs.operatorsPerShiftCurrent}
                    onChange={(value) => handleInputChange('operatorsPerShiftCurrent', value)}
                    min={1}
                    max={20}
                  />
                  <SliderInput
                    label="Operator Hours per Week"
                    value={inputs.operatorHoursCurrent}
                    onChange={(value) => handleInputChange('operatorHoursCurrent', value)}
                    min={30}
                    max={60}
                  />
                  <SliderInput
                    label="Operator Wage ($/hr)"
                    value={inputs.operatorWageCurrent}
                    onChange={(value) => handleInputChange('operatorWageCurrent', value)}
                    min={10}
                    max={100}
                    suffix="$"
                  />
                  <SliderInput
                    label="Technicians"
                    value={inputs.techniciansCurrent}
                    onChange={(value) => handleInputChange('techniciansCurrent', value)}
                    min={0}
                    max={5}
                  />
                  <SliderInput
                    label="Annual Cost per Technician"
                    value={inputs.annualCostPerTechnicianCurrent}
                    onChange={(value) => handleInputChange('annualCostPerTechnicianCurrent', value)}
                    min={50000}
                    max={100000}
                    suffix="$"
                  />
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-darkBlue mb-4">Post Install</h3>
                  <SliderInput
                    label="Work Shifts"
                    value={inputs.workShiftsPost}
                    onChange={(value) => handleInputChange('workShiftsPost', value)}
                    min={1}
                    max={3}
                  />
                  <SliderInput
                    label="Days per Year"
                    value={inputs.daysPerYearPost}
                    onChange={(value) => handleInputChange('daysPerYearPost', value)}
                    min={200}
                    max={365}
                  />
                  <SliderInput
                    label="Hours per Shift"
                    value={inputs.hoursPerShiftPost}
                    onChange={(value) => handleInputChange('hoursPerShiftPost', value)}
                    min={6}
                    max={12}
                  />
                  <SliderInput
                    label="Operators per Shift"
                    value={inputs.operatorsPerShiftPost}
                    onChange={(value) => handleInputChange('operatorsPerShiftPost', value)}
                    min={1}
                    max={20}
                  />
                  <SliderInput
                    label="Operator Hours per Week"
                    value={inputs.operatorHoursPost}
                    onChange={(value) => handleInputChange('operatorHoursPost', value)}
                    min={30}
                    max={60}
                  />
                  <SliderInput
                    label="Operator Wage ($/hr)"
                    value={inputs.operatorWagePost}
                    onChange={(value) => handleInputChange('operatorWagePost', value)}
                    min={10}
                    max={100}
                    suffix="$"
                  />
                  <SliderInput
                    label="Technicians"
                    value={inputs.techniciansPost}
                    onChange={(value) => handleInputChange('techniciansPost', value)}
                    min={0}
                    max={5}
                  />
                  <SliderInput
                    label="Annual Cost per Technician"
                    value={inputs.annualCostPerTechnicianPost}
                    onChange={(value) => handleInputChange('annualCostPerTechnicianPost', value)}
                    min={50000}
                    max={100000}
                    suffix="$"

                  />
                </div>
              </div>

              
            </div>

            {/* Materials Section */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex items-center space-x-3 mb-8">
                <Package className="w-6 h-6 text-lightGreen" />
                <h2 className="text-xl font-bold text-darkBlue">Materials & Production</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div>
                  <h3 className="text-lg font-semibold text-darkBlue mb-4">Current State</h3>
                  <SliderInput
                    label="Annual Parts Goal"
                    value={inputs.annualPartsGoalCurrent}
                    onChange={(value) => handleInputChange('annualPartsGoalCurrent', value)}
                    min={500000}
                    max={2000000}
                  />
                  <SliderInput
                    label="Machine Uptime"
                    value={inputs.machineUptimeCurrent}
                    onChange={(value) => handleInputChange('machineUptimeCurrent', value)}
                    min={60}
                    max={95}
                    suffix="%"
                  />
                  
                  <SliderInput
                    label="Scrap Percentage"
                    value={inputs.scrapPercentageCurrent}
                    onChange={(value) => handleInputChange('scrapPercentageCurrent', value)}
                    min={1}
                    max={15}
                    suffix="%"
                  />
                  <SliderInput
                    label="Material Cost per Unit"
                    value={inputs.materialCostPerUnitCurrent}
                    onChange={(value) => handleInputChange('materialCostPerUnitCurrent', value)}
                    min={5}
                    max={25}
                    suffix="$"
                  />
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-darkBlue mb-4">Post Install</h3>
                  <SliderInput
                    label="Annual Parts Goal"
                    value={inputs.annualPartsGoalPost}
                    onChange={(value) => handleInputChange('annualPartsGoalPost', value)}
                    min={500000}
                    max={2000000}
                  />
                  <SliderInput
                    label="Machine Uptime"
                    value={inputs.machineUptimePost}
                    onChange={(value) => handleInputChange('machineUptimePost', value)}
                    min={60}
                    max={98}
                    suffix="%"
                  />
                  <SliderInput
                    label="Scrap Percentage"
                    value={inputs.scrapPercentagePost}
                    onChange={(value) => handleInputChange('scrapPercentagePost', value)}
                    min={0.5}
                    max={15}
                    suffix="%"
                    step={0.1}
                  />
                  <SliderInput
                    label="Material Cost per Unit"
                    value={inputs.materialCostPerUnitPost}
                    onChange={(value) => handleInputChange('materialCostPerUnitPost', value)}
                    min={5}
                    max={25}
                    suffix="$"
                  />
                </div>
              </div>

            </div>

            {/* Investment Section */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex items-center space-x-3 mb-8">
                <Factory className="w-6 h-6 text-lightGreen" />
                <h2 className="text-xl font-bold text-darkBlue">Investment & Revenue</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <SliderInput
                  label="New Equipment Cost"
                  value={inputs.newEquipmentCost}
                  onChange={(value) => handleInputChange('newEquipmentCost', value)}
                  min={500000}
                  max={5000000}
                  suffix="$"
                />
                <SliderInput
                  label="Sell Price per Part (Current)"
                  value={inputs.sellPricePerPartCurrent}
                  onChange={(value) => handleInputChange('sellPricePerPartCurrent', value)}
                  min={10}
                  max={50}
                  suffix="$"
                  step={0.1}
                />
                 <SliderInput
                  label="Sell Price per Part (Post)"
                  value={inputs.sellPricePerPartPost}
                  onChange={(value) => handleInputChange('sellPricePerPartPost', value)}
                  min={10}
                  max={50}
                  suffix="$"
                  step={0.1}
                />
              </div>

              

              <button
                onClick={() => setShowResults(true)}
                className="w-full mt-8 text-white font-bold bg-darkBlue py-4 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                Calculate Comprehensive ROI
              </button>
            </div>
          </div>

          {/* Results Panel */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-xl p-8 sticky top-24">
              <div className="flex items-center space-x-3 mb-8">
                <TrendingUp className="w-6 h-6 text-lightGreen" />
                <h2 className="text-xl font-bold text-darkBlue">ROI Analysis</h2>
              </div>

              {showResults ? (
                <div className="space-y-6">
                  {/* Key Metrics */}
                  <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-6 text-center">
                    <DollarSign className="w-10 h-10 text-darkBlue mx-auto mb-3" />
                    <p className="text-sm text-darkBlue font-medium">Contribution Margin Improvement</p>
                    <p className="text-3xl font-bold text-darkBlue">${results.contributionMarginImprovement?.toLocaleString()}</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-4 text-center">
                      <Clock className="w-8 h-8 text-darkBlue mx-auto mb-2" />
                      <p className="text-sm text-darkBlue font-medium">Payback Period</p>
                      <p className="text-2xl font-bold text-darkBlue">
                        {typeof results.paybackPeriod === 'number' ? `${results.paybackPeriod.toFixed(1)} months` : 'N/A'}
                      </p>
                    </div>
                    
                    <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-4 text-center">
                      <TrendingUp className="w-8 h-8 text-darkBlue mx-auto mb-2" />
                      <p className="text-sm text-darkBlue font-medium">Internal Rate of Return</p>
                      <p className="text-2xl font-bold text-darkBlue">{results.irr?.toFixed(1)}%</p>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-indigo-50 to-indigo-100 rounded-xl p-4 text-center">
                    <DollarSign className="w-8 h-8 text-darkBlue mx-auto mb-2" />
                    <p className="text-sm text-darkBlue font-medium">Net Present Value</p>
                    <p className="text-2xl font-bold text-darkBlue">${results.npv?.toLocaleString()}</p>
                  </div>

                  <div className="space-y-3">
                    <h3 className="font-semibold text-darkBlue">Savings Breakdown</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-darkBlue">Labor Savings:</span>
                        <span className="font-bold text-lightGreen">${results.laborSavings?.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-darkBlue">Material Savings:</span>
                        <span className="font-bold text-lightGreen">${results.materialSavings?.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-darkBlue">Revenue Increase:</span>
                        <span className="font-bold text-lightGreen">${results.revenueSavings?.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Calculator className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Configure your parameters and click "Calculate ROI" to see your results</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Detailed Results Section */}
        {showResults && (
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Current vs Post Install Comparison */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-darkBlue mb-6">Current vs Post Install</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-sm font-medium text-darkBlue border-b pb-2">
                  <span></span>
                  <span className="text-center">Current</span>
                  <span className="text-center">Post Install</span>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <span className="text-darkBlue">Total Labor Cost</span>
                  <span className="text-center font-bold text-lightGreen">${results.totalLaborCostCurrent?.toLocaleString()}</span>
                  <span className="text-center font-bold text-lightGreen">${results.totalLaborCostPost?.toLocaleString()}</span>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <span className="text-darkBlue">Material Cost</span>
                  <span className="text-center font-bold text-lightGreen">${results.annualMaterialCostCurrent?.toLocaleString()}</span>
                  <span className="text-center font-bold text-lightGreen">${results.annualMaterialCostPost?.toLocaleString()}</span>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <span className="text-darkBlue">Annual Revenue</span>
                  <span className="text-center font-bold text-lightGreen">${results.annualRevenueCurrent?.toLocaleString()}</span>
                  <span className="text-center font-bold text-lightGreen">${results.annualRevenuePost?.toLocaleString()}</span>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-sm border-t pt-2">
                  <span className="text-darkBlue font-medium">Contribution Margin</span>
                  <span className="text-center font-bold text-lightGreen">${results.contributionMarginCurrent?.toLocaleString()}</span>
                  <span className="text-center font-bold text-lightGreen">${results.contributionMarginPost?.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* 3-Year Cash Flow Projection */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-darkBlue mb-6">3-Year ROI</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm font-medium text-darkBlue border-b pb-2">
                  <span>Year</span>
                  <span className="text-right">ROI</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <span className="text-darkBlue">Year 1</span>
                  <span className="text-right font-bold text-lightGreen">${results.year1CashFlow?.toLocaleString()}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <span className="text-darkBlue">Year 2</span>
                  <span className="text-right font-bold text-lightGreen">${results.year2CashFlow?.toLocaleString()}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <span className="text-darkBlue">Year 3</span>
                  <span className="text-right font-bold text-lightGreen">${results.year3CashFlow?.toLocaleString()}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm border-t pt-2">
                  <span className="text-darkBlue font-medium">Net Cash Flow</span>
                  <span className="text-right font-bold text-lightGreen">${results.netCashFlow?.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ROICalculator;